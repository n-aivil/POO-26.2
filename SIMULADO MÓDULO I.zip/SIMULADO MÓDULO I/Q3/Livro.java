public class Livro{
	private String titulo;
	private double preco;
	private Autor autor;

	public Livro(String titulo, double preco, Autor autor){
		this.titulo = titulo;
		this.preco = preco;
		this.autor = autor;
	}

	public void exibirDetalhes(){
		String nomeAutor = autor.nome;
		System.out.println("Título: " + this.titulo + "\nAutor: " + nomeAutor);
		System.out.printf("Preço: R$%.2f", this.preco);
	}
}
