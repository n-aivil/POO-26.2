public class Main{
	public static void main(String[] args){
		Autor autorA = new Autor("Machado de Assis", "Brasileiro");

		Livro livroA = new Livro("Dom Casmurro", 30.0, autorA);

		livroA.exibirDetalhes();
	}
}
