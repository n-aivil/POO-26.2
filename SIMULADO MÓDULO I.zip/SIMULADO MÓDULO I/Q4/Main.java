public class Main{
	public static void main(String[] args){
		GestaoPedidos gestao = new GestaoPedidos();

		gestao.adicionarPedido("Macarrão");
		gestao.adicionarPedido("Feijão");
		gestao.adicionarPedido("Arroz");

		System.out.println("Próximo pedido: " + gestao.proximoPedido());
		System.out.println("Pedidos restantes: " + gestao.quantidadePendentes());
	}
}
