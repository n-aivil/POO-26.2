public class Retangulo{
	private double largura;
	private double altura;

	public Retangulo(){
		setLargura(1.0);
		setAltura(1.0);
	}
	public Retangulo(double largura, double altura){
		setLargura(largura);
		setAltura(altura);
	}

	public void setLargura(double largura){
		if(valida(largura)){
			this.largura = largura;
		}else{
			System.out.println("Largura inválida.");
		}
	}
	public double getLargura(){
		return largura;
	}

	public void setAltura(double altura){
		if(valida(altura)){
			this.altura = altura;
		}else{
			System.out.println("Altura inválida.");
		}
	}
	public double getAltura(){
		return altura;
	}

	public boolean valida(double atributo){
		if(atributo > 0){
			return true;
		}else{
			return false;
		}
	}

	public double calcularArea(){
		return largura * altura;
	}

	public boolean isQuadrado(){
		if(this.largura == this.altura){
			return true;
		}else{
			return false;
		}
	}
}
