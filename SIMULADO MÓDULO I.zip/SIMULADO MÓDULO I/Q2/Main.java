public class Main{
	public static void main(String[] args){
		Retangulo retanguloA = new Retangulo(5.0, 5.0);

		System.out.println(retanguloA.isQuadrado() ? "É um quadrado." : "Não é um quadrado.");
		System.out.println("Área: " + retanguloA.calcularArea());
	}
}
